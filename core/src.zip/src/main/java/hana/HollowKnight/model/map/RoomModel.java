package hana.HollowKnight.model.map;

import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import hana.HollowKnight.model.entities.CrawlerModel;

import java.util.ArrayList;


public class RoomModel {

    private final String mapPath;
    private final Array<Rectangle> hazards = new Array<>();
    private final Array<Rectangle> solidTiles = new Array<>();
    private final Array<Rectangle> walls = new Array<>();
    private final Array<SpawnPointModel> enemySpawns = new Array<>();
    private ArrayList<CrawlerModel> crawlers = new ArrayList<>();
    private BreakableWallModel breakableWall;
    private PortalModel portal;
    private BossArena bossArena;
    private Vector2 knightSpawn = new Vector2(0, 0);
    private Vector2 zoteSpawn = new Vector2(0, 0);
    private float minX, minY, maxX, maxY;
    private float targetX, targetY;
    private MapLayer voidHeart;

    public RoomModel(String mapPath) {
        this.mapPath = mapPath;
    }

    public Array<Rectangle> getSolidTiles() {
        return solidTiles;
    }

    public Array<Rectangle> getWalls() {return walls;}

    public Array<Rectangle> getHazards() {
        return hazards;
    }

    public Array<SpawnPointModel> getEnemySpawns() {
        return enemySpawns;
    }

    public BreakableWallModel getBreakableWall() {
        return breakableWall;
    }

    public void setBreakableWall(BreakableWallModel wall) {
        this.breakableWall = wall;
    }

    public PortalModel getPortal() {
        return portal;
    }

    public void setPortal(PortalModel portal) {
        this.portal = portal;
    }

    public BossArena getBossArena() {
        return bossArena;
    }

    public void setBossArena(BossArena bossArena) {
        this.bossArena = bossArena;
    }

    public void setBounds(float minX, float minY, float maxX, float maxY) {
        this.minX = minX;
        this.minY = minY;
        this.maxX = maxX;
        this.maxY = maxY;
    }

    public float getMinX() {
        return minX;
    }

    public float getMinY() {
        return minY;
    }

    public float getMaxX() {
        return maxX;
    }

    public float getMaxY() {
        return maxY;
    }

    public Vector2 getKnightSpawn() {
        return knightSpawn;
    }

    public void setKnightSpawn(float x, float y) {
        this.knightSpawn.set(x, y);
    }

    public ArrayList<CrawlerModel> getCrawlers() {
        return crawlers;
    }

    public void setCrawlers(ArrayList<CrawlerModel> crawlers) {
        this.crawlers = crawlers;
    }

    public float getTargetX() {
        return targetX;
    }

    public void setTargetX(float targetX) {
        this.targetX = targetX;
    }

    public float getTargetY() {
        return targetY;
    }

    public void setTargetY(float targetY) {
        this.targetY = targetY;
    }

    public MapLayer getVoidHeart() {
        return voidHeart;
    }

    public void setVoidHeart(MapLayer voidHeart) {
        this.voidHeart = voidHeart;
    }

    public Vector2 getZoteSpawn() {
        return zoteSpawn;
    }

    public void setZoteSpawn(float x, float y) {
        this.zoteSpawn =  new Vector2(x , y);
    }
}
