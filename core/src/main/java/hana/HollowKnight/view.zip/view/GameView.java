package hana.HollowKnight.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.maps.tiled.tiles.AnimatedTiledMapTile;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import hana.HollowKnight.controller.GameController;
import hana.HollowKnight.model.entities.PlayerModel;
import hana.HollowKnight.view.hud.GameHUD;
import hana.HollowKnight.view.screens.BaseScreen;

public class GameView extends BaseScreen {

    private GameHUD hud;
    // استفاده از batch کلاس مادر (BaseScreen) به جای تعریف مجدد
    private PlayerModel player = controller.getModel().getPlayer();

    // متغیرهای مپ Tiled
    private TiledMap map;
    private OrthogonalTiledMapRenderer mapRenderer;

    public GameView(GameController controller) {
        super(controller);
    }

    @Override
    public void show() {
        Skin hudSkin = new Skin(Gdx.files.internal("ui/uiskin.json"));
        hud = new GameHUD();

        // لود کردن فایل مپ تمیز شده از پوشه assets/map
        map = new TmxMapLoader().load("maps/City of Tears-20260707T215923Z-3-001/cityOfTears1.tmx");

        // ساخت رندرر مپ با مقیاس واقعی
        mapRenderer = new OrthogonalTiledMapRenderer(map, 4f);

        camera.position.set(500, 500, 0);

    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.2f, 0.4f, 0.6f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        controller.updateGameplay(delta);
        
        camera.position.set(587, 300, 0);
        camera.update();

         hud.render(batch, player.getHealth(), player.getMaxHealth(), player.getSoul(), player.getMaxSoul());
         drawBrightnessOverlay();
    }

//    @Override
//    public void render(float delta) {
//        super.render(delta);
//        controller.updateGameplay(delta);
//
//        camera.position.set(500, 500, 0);
//
//        camera.update();
//
//        // ۳. آپدیت زمان انیمیشن‌های تایل‌ها (مثل آتش و آب‌نماها)
////        AnimatedTiledMapTile.updateAnimationBaseTime();
//        // ۴. رندر مپ (ماتریس دوربین بازی را به مپ‌رندرر معرفی می‌کنیم)
//        mapRenderer.setView(camera);
//        mapRenderer.render();
//
//        // ۵. تنظیم مجدد ماتریس بچ اصلی برای بقیه المان‌های بازی
//        batch.setProjectionMatrix(camera.combined);
//
//        // ۶. رسم کاراکتر بازی (اگر متد درایور بازیکن را اینجا داری، متصلش کن)
//        // batch.begin();
//        // player.draw(batch);
//        // batch.end();
//
//        hud.render(batch, player.getHealth(), player.getMaxHealth(), player.getSoul(), player.getMaxSoul());
//
//        // ۸. افکت تاریکی یا روشنایی محیط
//        drawBrightnessOverlay();
//    }

    @Override
    public void resize(int width, int height) {
        super.resize(width, height);
        // ویوپورت مپ را آپدیت می‌کند
        viewport.update(width, height, false);
        if (hud != null) hud.resize(width, height);
    }

    @Override
    public void dispose() {
        super.dispose();
        if (hud != null) hud.dispose();
        if (map != null) map.dispose();
        if (mapRenderer != null) mapRenderer.dispose();
        // توجه: batch را اینجا dispose نکن چون متعلق به GameController است و بقیه اسکرین‌ها به آن نیاز دارند
    }
}
